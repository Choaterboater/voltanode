import { memo } from 'react';
import { Check } from 'lucide-react';

interface CheckboxProps {
  id?: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  label?: string;
  disabled?: boolean;
  'aria-label'?: string;
}

const Checkbox = memo(function Checkbox({
  id,
  checked,
  onCheckedChange,
  label,
  disabled = false,
  'aria-label': ariaLabel,
}: CheckboxProps) {
  const checkboxId = id || `checkbox-${Math.random().toString(36).slice(2, 9)}`;

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        id={checkboxId}
        role="checkbox"
        aria-checked={checked}
        aria-label={ariaLabel}
        disabled={disabled}
        onClick={() => onCheckedChange(!checked)}
        className={`
          flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-md border transition-all
          ${checked
            ? 'border-accent-cyan bg-accent-cyan'
            : 'border-border-active bg-transparent hover:border-text-secondary'
          }
          ${disabled ? 'cursor-not-allowed opacity-40' : 'cursor-pointer'}
        `}
      >
        {checked && (
          <Check className="h-3.5 w-3.5 text-white" strokeWidth={3} />
        )}
      </button>
      {label && (
        <label
          htmlFor={checkboxId}
          className="cursor-pointer text-xs text-text-secondary transition-colors hover:text-text-primary"
        >
          {label}
        </label>
      )}
    </div>
  );
});

export { Checkbox };
export default Checkbox;

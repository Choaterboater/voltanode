import { memo, useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Shield, X } from 'lucide-react';
import { useTradingMode } from '@/context/TradingModeContext';
import { Checkbox } from '@/components/Checkbox';

const MODE_KEY = 'volta-mode';

const ConfirmationModal = memo(function ConfirmationModal({
  isLive,
  onConfirm,
  onCancel,
}: {
  isLive: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const [checked, setChecked] = useState(false);
  const goingLive = !isLive;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-end justify-center bg-black/70 sm:items-center"
      onClick={onCancel}
      role="dialog"
      aria-modal="true"
      aria-labelledby="mode-confirm-title"
    >
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="w-full max-w-md rounded-t-xl border border-border-active bg-bg-surface p-6 shadow-2xl sm:rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-3">
          <div
            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
              goingLive ? 'bg-danger-red-glow' : 'bg-accent-cyan-glow'
            }`}
          >
            {goingLive ? (
              <AlertTriangle className="h-5 w-5 text-danger-red" />
            ) : (
              <Shield className="h-5 w-5 text-accent-cyan" />
            )}
          </div>
          <div className="flex-1">
            <h3
              id="mode-confirm-title"
              className="text-base font-semibold text-text-primary"
            >
              {goingLive ? 'Switch to Live Mode?' : 'Return to Paper Mode?'}
            </h3>
            <p className="mt-1 text-sm text-text-secondary">
              {goingLive
                ? 'You are about to switch to live trading with REAL MONEY. All subsequent orders will be executed on your connected broker account. Paper trading data tracking will be paused.'
                : 'Switching back to paper mode will stop all live trading. Your paper portfolio will resume from its last tracked state.'}
            </p>

            {goingLive && (
              <div className="mt-4 flex items-start gap-2 rounded-lg border border-danger-red/30 bg-danger-red-glow p-3">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-danger-red" />
                <p className="text-xs text-danger-red">
                  This action cannot be undone immediately. Ensure your safety
                  limits and broker connection are properly configured.
                </p>
              </div>
            )}

            {goingLive && (
              <div className="mt-4 flex items-center gap-2">
                <Checkbox
                  id="understand-risk"
                  checked={checked}
                  onCheckedChange={(v) => setChecked(v === true)}
                  label="I understand this will use real money"
                />
              </div>
            )}

            <div className="mt-5 flex gap-3">
              <button
                onClick={onCancel}
                className="flex-1 rounded-lg border border-border-subtle bg-bg-input px-4 py-2 text-sm font-medium text-text-primary transition-colors hover:bg-bg-elevated"
              >
                Cancel
              </button>
              <button
                onClick={onConfirm}
                disabled={goingLive && !checked}
                className={`flex-1 rounded-lg px-4 py-2 text-sm font-bold tracking-wider text-white transition-all active:scale-95 ${
                  goingLive
                    ? 'bg-danger-red hover:bg-danger-red/80 disabled:opacity-40 disabled:active:scale-100'
                    : 'bg-accent-cyan hover:bg-accent-cyan/80'
                }`}
              >
                {goingLive ? 'GO LIVE' : 'SWITCH TO PAPER'}
              </button>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="rounded-md p-1 text-text-muted transition-colors hover:text-text-primary"
            aria-label="Close dialog"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
});

const ModeToggle = memo(function ModeToggle() {
  const { isLive, toggleMode, setLiveMode } = useTradingMode();
  const [showConfirm, setShowConfirm] = useState(false);

  /* Persist mode in localStorage */
  useEffect(() => {
    const saved = localStorage.getItem(MODE_KEY);
    if (saved === 'live') {
      setLiveMode(true);
    } else if (saved === 'paper') {
      setLiveMode(false);
    }
  }, [setLiveMode]);

  const handleToggle = useCallback(() => {
    toggleMode();
    const nextMode = !isLive ? 'live' : 'paper';
    localStorage.setItem(MODE_KEY, nextMode);
  }, [isLive, toggleMode]);

  return (
    <>
      <button
        onClick={() => setShowConfirm(true)}
        className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-bold tracking-wider transition-all ${
          isLive
            ? 'border-danger-red bg-danger-red-glow text-danger-red animate-pulse'
            : 'border-accent-cyan bg-accent-cyan-glow text-accent-cyan'
        }`}
        aria-label={isLive ? 'Currently in live mode. Click to switch.' : 'Currently in paper mode. Click to switch.'}
      >
        {isLive ? (
          <AlertTriangle className="h-3.5 w-3.5" />
        ) : (
          <Shield className="h-3.5 w-3.5" />
        )}
        {isLive ? 'LIVE MODE' : 'PAPER MODE'}
      </button>

      <AnimatePresence>
        {showConfirm && (
          <ConfirmationModal
            isLive={isLive}
            onConfirm={() => {
              handleToggle();
              setShowConfirm(false);
            }}
            onCancel={() => setShowConfirm(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
});

export default ModeToggle;

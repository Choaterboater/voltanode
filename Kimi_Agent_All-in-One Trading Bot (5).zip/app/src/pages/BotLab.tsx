import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bot,
  Play,
  Pause,
  Shield,
  AlertTriangle,
  Plus,
  X,
} from 'lucide-react';
import Layout from '@/components/Layout';
import Badge from '@/components/Badge';
import MetricCard from '@/components/MetricCard';
import { useTradingMode } from '@/context/TradingModeContext';

interface BotConfig {
  id: string;
  name: string;
  symbol: string;
  strategy: string;
  status: 'running' | 'stopped' | 'paused';
  mode: 'paper' | 'live';
  pnl: number;
  pnlPct: number;
}

const initialBots: BotConfig[] = [
  { id: '1', name: 'BTC Momentum', symbol: 'BTC', strategy: 'MACD Cross', status: 'running', mode: 'paper', pnl: 1240, pnlPct: 2.4 },
  { id: '2', name: 'ETH Scalper', symbol: 'ETH', strategy: 'RSI Reversal', status: 'paused', mode: 'paper', pnl: -320, pnlPct: -0.8 },
  { id: '3', name: 'SOL Breakout', symbol: 'SOL', strategy: 'Bollinger', status: 'running', mode: 'live', pnl: 560, pnlPct: 1.2 },
  { id: '4', name: 'AAPL Swing', symbol: 'AAPL', strategy: 'EMA Cloud', status: 'stopped', mode: 'paper', pnl: 0, pnlPct: 0 },
];

function BotCard({ bot }: { bot: BotConfig }) {
  const isLive = bot.mode === 'live';

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-xl border p-5 transition-all hover:-translate-y-0.5 ${
        isLive
          ? 'border-danger-red/40 bg-danger-red-glow hover:border-danger-red/60'
          : 'border-border-subtle bg-bg-surface hover:border-accent-cyan/20'
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div
            className={`flex h-9 w-9 items-center justify-center rounded-lg ${
              isLive ? 'bg-danger-red/10' : 'bg-accent-cyan-glow'
            }`}
          >
            <Bot
              className={`h-5 w-5 ${
                isLive ? 'text-danger-red' : 'text-accent-cyan'
              }`}
            />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-text-primary">
              {bot.name}
            </h4>
            <p className="text-xs text-text-muted">
              {bot.symbol} · {bot.strategy}
            </p>
          </div>
        </div>
        <Badge variant={isLive ? 'danger' : 'cyan'}>
          {isLive ? 'LIVE' : 'PAPER'}
        </Badge>
      </div>

      <div className="mt-4 flex items-end justify-between">
        <div>
          <p className="text-xs text-text-muted">P&L</p>
          <p
            className={`font-mono text-lg tabular-nums ${
              bot.pnl >= 0 ? 'text-success-green' : 'text-danger-red'
            }`}
          >
            {bot.pnl >= 0 ? '+' : ''}${bot.pnl.toLocaleString()}
          </p>
          <p
            className={`text-xs font-mono tabular-nums ${
              bot.pnlPct >= 0 ? 'text-success-green' : 'text-danger-red'
            }`}
          >
            {bot.pnlPct >= 0 ? '+' : ''}
            {bot.pnlPct}%
          </p>
        </div>
        <div className="flex items-center gap-2">
          {bot.status === 'running' && (
            <button
              className="flex h-8 w-8 items-center justify-center rounded-md border border-border-subtle bg-bg-input text-text-secondary transition-colors hover:text-text-primary"
              aria-label="Pause bot"
            >
              <Pause className="h-4 w-4" />
            </button>
          )}
          {bot.status === 'paused' && (
            <button
              className="flex h-8 w-8 items-center justify-center rounded-md border border-border-subtle bg-bg-input text-text-secondary transition-colors hover:text-text-primary"
              aria-label="Resume bot"
            >
              <Play className="h-4 w-4" />
            </button>
          )}
          {bot.status === 'stopped' && (
            <button
              className={`flex h-8 w-8 items-center justify-center rounded-md border text-white transition-colors hover:opacity-80 ${
                isLive
                  ? 'border-danger-red bg-danger-red'
                  : 'border-accent-cyan bg-accent-cyan'
              }`}
              aria-label="Start bot"
            >
              <Play className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function CreateBotModal({
  onClose,
}: {
  onClose: () => void;
}) {
  const { isLive: globalIsLive } = useTradingMode();
  const [name, setName] = useState('');
  const [symbol, setSymbol] = useState('BTC');
  const [strategy, setStrategy] = useState('MACD Cross');
  const [mode, setMode] = useState<'paper' | 'live'>(globalIsLive ? 'live' : 'paper');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-end justify-center bg-black/60 sm:items-center"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="w-full max-w-md rounded-t-xl border border-border-subtle bg-bg-surface p-6 shadow-2xl sm:rounded-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-semibold text-text-primary">
            Create New Bot
          </h3>
          <button
            onClick={onClose}
            className="rounded-md p-1 text-text-muted transition-colors hover:text-text-primary"
            aria-label="Close modal"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-xs text-text-muted">Bot Name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. BTC Momentum"
              className="w-full rounded-md border border-border-subtle bg-bg-input px-3 py-2 text-sm text-text-primary outline-none focus:border-accent-cyan"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs text-text-muted">Symbol</label>
            <input
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              className="w-full rounded-md border border-border-subtle bg-bg-input px-3 py-2 text-sm font-mono text-text-primary outline-none focus:border-accent-cyan"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs text-text-muted">Strategy</label>
            <select
              value={strategy}
              onChange={(e) => setStrategy(e.target.value)}
              className="w-full rounded-md border border-border-subtle bg-bg-input px-3 py-2 text-sm text-text-primary outline-none focus:border-accent-cyan"
            >
              <option>MACD Cross</option>
              <option>RSI Reversal</option>
              <option>Bollinger Bands</option>
              <option>EMA Cloud</option>
              <option>Breakout Momentum</option>
            </select>
          </div>

          {/* Mode Selector */}
          <div className="rounded-lg border border-border-subtle bg-bg-input p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {mode === 'live' ? (
                  <AlertTriangle className="h-4 w-4 text-danger-red" />
                ) : (
                  <Shield className="h-4 w-4 text-accent-cyan" />
                )}
                <span className="text-sm font-medium text-text-primary">
                  {mode === 'live' ? 'Live Mode' : 'Paper Mode'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setMode('paper')}
                  className={`rounded-md px-3 py-1 text-xs font-bold transition-all ${
                    mode === 'paper'
                      ? 'bg-accent-cyan text-white'
                      : 'text-text-muted hover:text-text-primary'
                  }`}
                >
                  PAPER
                </button>
                <button
                  onClick={() => setMode('live')}
                  className={`rounded-md px-3 py-1 text-xs font-bold transition-all ${
                    mode === 'live'
                      ? 'bg-danger-red text-white'
                      : 'text-text-muted hover:text-text-primary'
                  }`}
                >
                  LIVE
                </button>
              </div>
            </div>
            {mode === 'live' && (
              <p className="mt-2 text-[10px] text-danger-red">
                This bot will trade with REAL MONEY when activated.
              </p>
            )}
          </div>
        </div>

        <div className="mt-5 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 rounded-lg border border-border-subtle bg-bg-input py-2 text-sm font-medium text-text-primary transition-colors hover:bg-bg-elevated"
          >
            Cancel
          </button>
          <button
            onClick={onClose}
            className={`flex-1 rounded-lg py-2 text-sm font-bold text-white transition-colors active:scale-95 ${
              mode === 'live'
                ? 'bg-danger-red hover:bg-danger-red/80'
                : 'bg-accent-cyan hover:bg-accent-cyan/80'
            }`}
          >
            Create {mode === 'live' ? 'LIVE' : 'Paper'} Bot
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function BotLab() {
  const { isLive } = useTradingMode();
  const [bots] = useState<BotConfig[]>(initialBots);
  const [showCreate, setShowCreate] = useState(false);

  return (
    <Layout
      title="Bot Lab"
      rightContent={
        <button
          onClick={() => setShowCreate(true)}
          className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold tracking-wider text-white transition-all active:scale-95 ${
            isLive
              ? 'bg-danger-red hover:bg-danger-red/80'
              : 'bg-accent-cyan hover:bg-accent-cyan/80'
          }`}
        >
          <Plus className="h-3.5 w-3.5" />
          New Bot
        </button>
      }
    >
      {/* Stats */}
      <div className="mb-6 grid gap-4 sm:grid-cols-4">
        <MetricCard label="Total Bots" value={bots.length} delay={0} />
        <MetricCard label="Running" value={bots.filter((b) => b.status === 'running').length} delay={0.05} />
        <MetricCard label="Live Bots" value={bots.filter((b) => b.mode === 'live').length} delay={0.1} />
        <MetricCard label="Total P&L" value="+$1,480.00" delta="+3.2%" deltaPositive={true} delay={0.15} />
      </div>

      {/* Bot Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {bots.map((bot) => (
          <BotCard key={bot.id} bot={bot} />
        ))}

        {/* Create placeholder card */}
        <button
          onClick={() => setShowCreate(true)}
          className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border-subtle bg-bg-surface p-5 transition-all hover:border-accent-cyan/40 hover:bg-accent-cyan-glow"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-bg-elevated">
            <Plus className="h-6 w-6 text-text-muted" />
          </div>
          <span className="text-sm font-medium text-text-muted">
            Create New Bot
          </span>
        </button>
      </div>

      <AnimatePresence>
        {showCreate && <CreateBotModal onClose={() => setShowCreate(false)} />}
      </AnimatePresence>
    </Layout>
  );
}

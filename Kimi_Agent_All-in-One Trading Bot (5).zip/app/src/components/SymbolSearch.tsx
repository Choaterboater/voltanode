import { useState, useMemo, useCallback, useRef, useEffect, memo } from 'react';
import { Search, X } from 'lucide-react';
import { symbols, type SymbolInfo } from '@/data/symbols';

interface SymbolSearchProps {
  onSelect?: (symbol: SymbolInfo) => void;
  filterType?: 'all' | 'crypto' | 'stock' | 'forex';
  placeholder?: string;
}

const SymbolSearch = memo(function SymbolSearch({
  onSelect,
  filterType = 'all',
  placeholder = 'Search symbols...',
}: SymbolSearchProps) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  /* Debounce query for smoother UX */
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }
    debounceTimer.current = setTimeout(() => {
      setDebouncedQuery(query);
    }, 200);
    return () => {
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current);
      }
    };
  }, [query]);

  /* Memoized filtered results */
  const results = useMemo(() => {
    const q = debouncedQuery.trim().toLowerCase();
    if (!q) return [];

    return symbols.filter((s) => {
      const matchesQuery =
        s.symbol.toLowerCase().includes(q) ||
        s.name.toLowerCase().includes(q);
      const matchesFilter =
        filterType === 'all' || s.type === filterType;
      return matchesQuery && matchesFilter;
    });
  }, [debouncedQuery, filterType]);

  /* Keep dropdown open while typing */
  const showDropdown = isOpen && query.length > 0;

  const handleSelect = useCallback(
    (symbol: SymbolInfo) => {
      onSelect?.(symbol);
      setQuery(symbol.symbol);
      setIsOpen(false);
      inputRef.current?.blur();
    },
    [onSelect]
  );

  const handleClear = useCallback(() => {
    setQuery('');
    setDebouncedQuery('');
    setIsOpen(false);
    inputRef.current?.focus();
  }, []);

  /* Close on outside click */
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative w-full max-w-md">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text-muted" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder}
          className="w-full rounded-lg border border-border-subtle bg-bg-input py-2 pl-10 pr-9 text-sm text-text-primary placeholder:text-text-muted focus:border-accent-cyan focus:outline-none focus:ring-1 focus:ring-accent-cyan"
          aria-autocomplete="list"
          aria-controls="symbol-search-results"
          aria-expanded={showDropdown}
        />
        {query && (
          <button
            onClick={handleClear}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-text-muted hover:text-text-primary"
            aria-label="Clear search"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {showDropdown && (
        <div
          id="symbol-search-results"
          className="absolute z-50 mt-1 max-h-72 w-full overflow-auto rounded-lg border border-border-subtle bg-bg-surface shadow-xl"
        >
          {results.length === 0 ? (
            <div className="px-4 py-6 text-center text-sm text-text-muted">
              No symbols found for &apos;{debouncedQuery}&apos;
            </div>
          ) : (
            <ul role="listbox">
              {results.map((s) => (
                <li key={s.symbol} role="option">
                  <button
                    onClick={() => handleSelect(s)}
                    className="flex w-full items-center justify-between px-4 py-2.5 text-left text-sm transition-colors hover:bg-bg-elevated"
                  >
                    <div>
                      <span className="font-semibold text-text-primary">
                        {s.symbol}
                      </span>
                      <span className="ml-2 text-text-muted">{s.name}</span>
                    </div>
                    <span className="rounded bg-bg-elevated px-1.5 py-0.5 text-[10px] uppercase text-text-muted">
                      {s.type}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
});

export default SymbolSearch;

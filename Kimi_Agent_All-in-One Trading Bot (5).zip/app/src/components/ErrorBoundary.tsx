import { Component, type ReactNode, type ErrorInfo } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // eslint-disable-next-line no-console
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  private handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="flex min-h-[100dvh] flex-col items-center justify-center bg-bg-base px-6 text-center">
          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-danger-red/10">
            <svg
              className="h-8 w-8 text-danger-red"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4.5c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
              />
            </svg>
          </div>
          <h1 className="mb-2 text-xl font-bold text-text-primary">
            Something went wrong
          </h1>
          <p className="mb-6 max-w-sm text-sm text-text-secondary">
            An unexpected error occurred in the application. Please reload the
            page to continue.
          </p>
          {this.state.error && (
            <pre className="mb-6 max-w-md overflow-auto rounded-lg border border-border-subtle bg-bg-surface p-3 text-left text-xs text-text-muted">
              {this.state.error.message}
            </pre>
          )}
          <button
            onClick={this.handleReload}
            className="rounded-lg bg-accent-cyan px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-accent-cyan/80 active:scale-95"
          >
            Reload Page
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

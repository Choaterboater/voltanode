import { createRoot } from 'react-dom/client'
import { HashRouter } from 'react-router'
import './index.css'
import App from './App.tsx'
import { TradingModeProvider } from './context/TradingModeContext'
import ErrorBoundary from './components/ErrorBoundary'

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary>
    <HashRouter>
      <TradingModeProvider>
        <App />
      </TradingModeProvider>
    </HashRouter>
  </ErrorBoundary>,
)

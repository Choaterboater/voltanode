import { useState, useEffect, useCallback, useRef } from 'react';
import type { MarketTicker } from '@/types';
import { marketTickers as fallbackTickers } from '@/data/mockData';

const API_TIMEOUT_MS = 3000;
const MAX_RETRIES = 2;
const RETRY_DELAY_MS = 1000;

function fetchWithTimeout(
  url: string,
  options?: RequestInit,
  timeout = API_TIMEOUT_MS
): Promise<Response> {
  return Promise.race([
    fetch(url, options),
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Request timed out')), timeout)
    ),
  ]);
}

async function fetchWithRetry(
  url: string,
  retries = MAX_RETRIES
): Promise<MarketTicker[]> {
  try {
    const res = await fetchWithTimeout(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as MarketTicker[];
  } catch (err) {
    if (retries > 0) {
      await new Promise((r) => setTimeout(r, RETRY_DELAY_MS));
      return fetchWithRetry(url, retries - 1);
    }
    throw err;
  }
}

export function useMarketData() {
  const [data, setData] = useState<MarketTicker[]>(fallbackTickers);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const mounted = useRef(true);

  const refresh = useCallback(async (apiUrl?: string) => {
    if (!mounted.current) return;
    setLoading(true);
    setError(null);

    try {
      const tickers = await fetchWithRetry(
        apiUrl ?? '/api/market/tickers'
      );
      if (mounted.current) {
        setData(tickers.length ? tickers : fallbackTickers);
        setError(null);
      }
    } catch (err) {
      if (mounted.current) {
        setData(fallbackTickers);
        setError(
          err instanceof Error ? err.message : 'Failed to fetch market data'
        );
      }
    } finally {
      if (mounted.current) {
        setLoading(false);
      }
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    // Auto-refresh on mount (with fallback)
    refresh();
    return () => {
      mounted.current = false;
    };
  }, [refresh]);

  return { data, loading, error, refresh };
}

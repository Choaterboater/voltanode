import {
  createContext,
  useContext,
  useState,
  useCallback,
  useMemo,
  type ReactNode,
} from 'react';

/* ──────────────── Types ──────────────── */

export interface SafetyStatus {
  maxDailyLossPct: number;
  maxPositionSizePct: number;
  maxExposurePct: number;
  maxOrdersPerMinute: number;
  requireOrderConfirmation: boolean;
  killSwitchOnDisconnect: boolean;
  allowedSymbols: string;
  blockedSymbols: string;
}

export interface PaperSettings {
  virtualBalance: number;
  slippageModel: string;
  feePct: number;
}

export interface KillSwitchState {
  active: boolean;
  reason: string;
  activatedAt: string | null;
}

export interface BrokerConfig {
  broker: 'mock' | 'binance' | 'alpaca';
  apiKey: string;
  apiSecret: string;
  useTestnet: boolean;
  connected: boolean;
}

/* ──────────────── Defaults ──────────────── */

const defaultSafetyStatus: SafetyStatus = {
  maxDailyLossPct: 5,
  maxPositionSizePct: 20,
  maxExposurePct: 50,
  maxOrdersPerMinute: 10,
  requireOrderConfirmation: true,
  killSwitchOnDisconnect: true,
  allowedSymbols: '',
  blockedSymbols: '',
};

const defaultPaperSettings: PaperSettings = {
  virtualBalance: 100000,
  slippageModel: 'fixed-0.1%',
  feePct: 0.1,
};

const defaultBrokerConfig: BrokerConfig = {
  broker: 'mock',
  apiKey: '',
  apiSecret: '',
  useTestnet: true,
  connected: false,
};

const defaultKillSwitch: KillSwitchState = {
  active: false,
  reason: '',
  activatedAt: null,
};

/* ──────────────── Context 1: Mode ──────────────── */

interface ModeContextValue {
  isLive: boolean;
  toggleMode: () => void;
  setLiveMode: (value: boolean) => void;
  dailyPnl: number;
  lossBudgetRemaining: number;
  killSwitch: KillSwitchState;
  activateKillSwitch: (reason: string) => void;
  resetKillSwitch: () => void;
}

const ModeContext = createContext<ModeContextValue>({
  isLive: false,
  toggleMode: () => {},
  setLiveMode: () => {},
  dailyPnl: 1234,
  lossBudgetRemaining: -500,
  killSwitch: defaultKillSwitch,
  activateKillSwitch: () => {},
  resetKillSwitch: () => {},
});

export function useMode() {
  const ctx = useContext(ModeContext);
  if (!ctx) throw new Error('useMode must be used within TradingModeProvider');
  return ctx;
}

/* ──────────────── Context 2: Broker ──────────────── */

interface BrokerContextValue {
  broker: BrokerConfig;
  setBroker: (config: Partial<BrokerConfig>) => void;
  apiKeysConfigured: boolean;
  brokerConnected: boolean;
  setApiKeysConfigured: (value: boolean) => void;
  setBrokerConnected: (value: boolean) => void;
}

const BrokerContext = createContext<BrokerContextValue>({
  broker: defaultBrokerConfig,
  setBroker: () => {},
  apiKeysConfigured: false,
  brokerConnected: false,
  setApiKeysConfigured: () => {},
  setBrokerConnected: () => {},
});

export function useBroker() {
  const ctx = useContext(BrokerContext);
  if (!ctx) throw new Error('useBroker must be used within TradingModeProvider');
  return ctx;
}

/* ──────────────── Context 3: Safety ──────────────── */

interface SafetyContextValue {
  safetyStatus: SafetyStatus;
  paperSettings: PaperSettings;
  setSafetyStatus: (status: Partial<SafetyStatus>) => void;
  setPaperSettings: (settings: Partial<PaperSettings>) => void;
  safetyLimitsSet: boolean;
  setSafetyLimitsSet: (value: boolean) => void;
}

const SafetyContext = createContext<SafetyContextValue>({
  safetyStatus: defaultSafetyStatus,
  paperSettings: defaultPaperSettings,
  setSafetyStatus: () => {},
  setPaperSettings: () => {},
  safetyLimitsSet: false,
  setSafetyLimitsSet: () => {},
});

export function useSafety() {
  const ctx = useContext(SafetyContext);
  if (!ctx) throw new Error('useSafety must be used within TradingModeProvider');
  return ctx;
}

/* ──────────────── Legacy Combined Hook ──────────────── */

export function useTradingMode() {
  const mode = useMode();
  const broker = useBroker();
  const safety = useSafety();
  return useMemo(
    () => ({
      ...mode,
      ...broker,
      ...safety,
    }),
    [mode, broker, safety]
  );
}

/* ──────────────── Provider ──────────────── */

export function TradingModeProvider({ children }: { children: ReactNode }) {
  const [isLive, setIsLive] = useState(() => {
    try {
      return localStorage.getItem('volta-mode') === 'live';
    } catch {
      return false;
    }
  });
  const [broker, setBrokerState] = useState<BrokerConfig>(defaultBrokerConfig);
  const [safetyStatus, setSafetyStatusState] = useState<SafetyStatus>(defaultSafetyStatus);
  const [paperSettings, setPaperSettingsState] = useState<PaperSettings>(defaultPaperSettings);
  const [killSwitch, setKillSwitch] = useState<KillSwitchState>(defaultKillSwitch);
  const [dailyPnl] = useState(1234);
  const [lossBudgetRemaining] = useState(-500);
  const [apiKeysConfigured, setApiKeysConfigured] = useState(false);
  const [brokerConnected, setBrokerConnected] = useState(false);
  const [safetyLimitsSet, setSafetyLimitsSet] = useState(false);

  const setBroker = useCallback((config: Partial<BrokerConfig>) => {
    setBrokerState((prev) => ({ ...prev, ...config }));
  }, []);

  const setSafetyStatus = useCallback((status: Partial<SafetyStatus>) => {
    setSafetyStatusState((prev) => ({ ...prev, ...status }));
  }, []);

  const setPaperSettings = useCallback((settings: Partial<PaperSettings>) => {
    setPaperSettingsState((prev) => ({ ...prev, ...settings }));
  }, []);

  const toggleMode = useCallback(() => {
    setIsLive((prev) => !prev);
  }, []);

  const setLiveMode = useCallback((value: boolean) => {
    setIsLive(value);
  }, []);

  const activateKillSwitch = useCallback((reason: string) => {
    setKillSwitch({
      active: true,
      reason,
      activatedAt: new Date().toLocaleString(),
    });
    setIsLive(false);
  }, []);

  const resetKillSwitch = useCallback(() => {
    setKillSwitch(defaultKillSwitch);
  }, []);

  const modeValue = useMemo(
    () => ({
      isLive,
      toggleMode,
      setLiveMode,
      dailyPnl,
      lossBudgetRemaining,
      killSwitch,
      activateKillSwitch,
      resetKillSwitch,
    }),
    [isLive, toggleMode, setLiveMode, dailyPnl, lossBudgetRemaining, killSwitch, activateKillSwitch, resetKillSwitch]
  );

  const brokerValue = useMemo(
    () => ({
      broker,
      setBroker,
      apiKeysConfigured,
      brokerConnected,
      setApiKeysConfigured,
      setBrokerConnected,
    }),
    [broker, setBroker, apiKeysConfigured, brokerConnected, setApiKeysConfigured, setBrokerConnected]
  );

  const safetyValue = useMemo(
    () => ({
      safetyStatus,
      paperSettings,
      setSafetyStatus,
      setPaperSettings,
      safetyLimitsSet,
      setSafetyLimitsSet,
    }),
    [safetyStatus, paperSettings, setSafetyStatus, setPaperSettings, safetyLimitsSet, setSafetyLimitsSet]
  );

  return (
    <ModeContext.Provider value={modeValue}>
      <BrokerContext.Provider value={brokerValue}>
        <SafetyContext.Provider value={safetyValue}>
          {children}
        </SafetyContext.Provider>
      </BrokerContext.Provider>
    </ModeContext.Provider>
  );
}

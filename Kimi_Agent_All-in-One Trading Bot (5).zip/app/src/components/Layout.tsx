import type { ReactNode } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import ModeToggle from './ModeToggle';
import LiveModeBanner from './LiveModeBanner';

interface LayoutProps {
  children: ReactNode;
  title: string;
  rightContent?: ReactNode;
}

export default function Layout({ children, title, rightContent }: LayoutProps) {
  return (
    <div className="flex min-h-[100dvh] bg-bg-base">
      <Navbar />

      {/* Main content area */}
      <div className="flex flex-1 flex-col lg:ml-[260px]">
        {/* Top bar */}
        <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-border-subtle bg-bg-base px-6">
          <h1 className="text-lg font-semibold text-text-primary">{title}</h1>
          <div className="flex items-center gap-4">
            {rightContent}
            <ModeToggle />
          </div>
        </header>

        {/* Live Mode Banner */}
        <LiveModeBanner />

        {/* Content */}
        <main className="flex-1 p-6">{children}</main>

        <Footer />
      </div>
    </div>
  );
}

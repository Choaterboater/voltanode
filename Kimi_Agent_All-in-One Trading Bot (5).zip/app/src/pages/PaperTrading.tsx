import { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, AlertTriangle, TrendingUp, ArrowRight, ArrowLeft } from 'lucide-react';
import Layout from '@/components/Layout';
import Badge from '@/components/Badge';
import MetricCard from '@/components/MetricCard';
import { useTradingMode } from '@/context/TradingModeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function PaperTrading() {
  const { isLive } = useTradingMode();
  const [symbol, setSymbol] = useState('BTC');
  const [qty, setQty] = useState('0.1');
  const [side, setSide] = useState<'buy' | 'sell'>('buy');

  return (
    <Layout
      title="Paper Trading"
      rightContent={
        <Badge variant={isLive ? 'danger' : 'cyan'}>
          {isLive ? (
            <>
              <AlertTriangle className="mr-1 h-3 w-3" /> LIVE
            </>
          ) : (
            <>
              <Shield className="mr-1 h-3 w-3" /> PAPER
            </>
          )}
        </Badge>
      }
    >
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Order Entry */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className={`rounded-xl border p-6 lg:col-span-1 ${
            isLive
              ? 'border-danger-red/40 bg-danger-red-glow'
              : 'border-border-subtle bg-bg-surface'
          }`}
        >
          <h3 className="text-sm font-semibold text-text-primary">
            Order Entry
          </h3>

          <div className="mt-4 space-y-4">
            <div>
              <Label className="mb-2 block text-xs text-text-muted">Symbol</Label>
              <Input
                value={symbol}
                onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                className="border-border-subtle bg-bg-input font-mono text-text-primary"
              />
            </div>
            <div>
              <Label className="mb-2 block text-xs text-text-muted">Quantity</Label>
              <Input
                type="number"
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                className="border-border-subtle bg-bg-input font-mono text-text-primary"
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setSide('buy')}
                className={`flex-1 rounded-lg py-2 text-sm font-bold transition-all active:scale-95 ${
                  side === 'buy'
                    ? 'bg-success-green text-white'
                    : 'border border-border-subtle bg-bg-input text-text-secondary'
                }`}
              >
                <ArrowRight className="mr-1 inline h-3.5 w-3.5" />
                BUY
              </button>
              <button
                onClick={() => setSide('sell')}
                className={`flex-1 rounded-lg py-2 text-sm font-bold transition-all active:scale-95 ${
                  side === 'sell'
                    ? 'bg-danger-red text-white'
                    : 'border border-border-subtle bg-bg-input text-text-secondary'
                }`}
              >
                <ArrowLeft className="mr-1 inline h-3.5 w-3.5" />
                SELL
              </button>
            </div>

            <button
              className={`w-full rounded-lg py-3 text-sm font-bold tracking-wider text-white transition-all active:scale-95 ${
                isLive
                  ? 'bg-danger-red hover:bg-danger-red/80'
                  : 'bg-accent-cyan hover:bg-accent-cyan/80'
              }`}
            >
              {isLive ? (
                <>
                  <AlertTriangle className="mr-2 inline h-4 w-4" />
                  Place LIVE Order
                </>
              ) : (
                <>
                  <Shield className="mr-2 inline h-4 w-4" />
                  Place Paper Order
                </>
              )}
            </button>
          </div>
        </motion.div>

        {/* Metrics */}
        <div className="grid gap-4 lg:col-span-2 lg:grid-cols-3">
          <MetricCard
            label="Portfolio Value"
            value="$102,450.00"
            delta="+$2,450.00"
            deltaPositive={true}
            icon={<TrendingUp className="h-5 w-5" />}
            delay={0}
          />
          <MetricCard
            label="Open P&L"
            value="+$1,234.50"
            delta="+1.21%"
            deltaPositive={true}
            delay={0.05}
          />
          <MetricCard
            label="Buying Power"
            value="$45,000.00"
            delta="-5.2%"
            deltaPositive={false}
            delay={0.1}
          />
        </div>
      </div>
    </Layout>
  );
}

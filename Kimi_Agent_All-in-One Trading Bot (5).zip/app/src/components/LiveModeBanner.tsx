import { memo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Octagon, X, RotateCcw } from 'lucide-react';
import { useTradingMode } from '@/context/TradingModeContext';

const KillSwitchConfirmModal = memo(function KillSwitchConfirmModal({
  onConfirm,
  onCancel,
}: {
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70"
      onClick={onCancel}
      role="dialog"
      aria-modal="true"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="mx-4 w-full max-w-sm rounded-xl border-2 border-danger-red bg-bg-surface p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col items-center text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-danger-red-glow">
            <Octagon className="h-6 w-6 text-danger-red" />
          </div>
          <h3 className="mt-3 text-lg font-bold text-danger-red">
            ACTIVATE KILL SWITCH?
          </h3>
          <p className="mt-2 text-sm text-text-secondary">
            This will immediately stop ALL trading activity, cancel open orders,
            and disconnect from the broker. This action cannot be undone
            without manual reset.
          </p>
          <div className="mt-5 flex w-full gap-3">
            <button
              onClick={onCancel}
              className="flex-1 rounded-lg border border-border-subtle bg-bg-input px-4 py-2 text-sm font-medium text-text-primary transition-colors hover:bg-bg-elevated"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              className="flex-1 rounded-lg bg-danger-red px-4 py-2 text-sm font-bold text-white transition-colors hover:bg-danger-red/80 active:scale-95"
            >
              CONFIRM
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
});

const KillSwitchResetModal = memo(function KillSwitchResetModal({
  onConfirm,
  onCancel,
}: {
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70"
      onClick={onCancel}
      role="dialog"
      aria-modal="true"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="mx-4 w-full max-w-sm rounded-xl border border-border-subtle bg-bg-surface p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col items-center text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning-amber/10">
            <RotateCcw className="h-6 w-6 text-warning-amber" />
          </div>
          <h3 className="mt-3 text-lg font-bold text-text-primary">
            Reset Kill Switch?
          </h3>
          <p className="mt-2 text-sm text-text-secondary">
            This will re-enable trading. Ensure you have reviewed the issue that
            triggered the kill switch before proceeding.
          </p>
          <div className="mt-5 flex w-full gap-3">
            <button
              onClick={onCancel}
              className="flex-1 rounded-lg border border-border-subtle bg-bg-input px-4 py-2 text-sm font-medium text-text-primary transition-colors hover:bg-bg-elevated"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              className="flex-1 rounded-lg bg-accent-cyan px-4 py-2 text-sm font-bold text-white transition-colors hover:bg-accent-cyan/80 active:scale-95"
            >
              RESET
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
});

const LiveModeBanner = memo(function LiveModeBanner() {
  const {
    isLive,
    dailyPnl,
    lossBudgetRemaining,
    broker,
    killSwitch,
    activateKillSwitch,
    resetKillSwitch,
  } = useTradingMode();

  const [showKillConfirm, setShowKillConfirm] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const shouldShow = isLive || killSwitch.active;

  return (
    <>
      <AnimatePresence initial={false}>
        {shouldShow && (
          <motion.div
            key="live-banner"
            initial={{ height: 0, opacity: 0, y: -8 }}
            animate={{ height: 'auto', opacity: 1, y: 0 }}
            exit={{ height: 0, opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="sticky top-0 z-30 overflow-hidden border-t-2 border-danger-red bg-gradient-to-b from-danger-red/20 to-bg-surface"
          >
            <div className="px-4 py-2">
              <div className="flex items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-danger-red" />
                    <span className="text-xs font-bold tracking-wider text-danger-red">
                      LIVE TRADING MODE — REAL MONEY AT RISK
                    </span>
                  </div>
                  <div className="hidden h-3 w-px bg-border-subtle sm:block" />
                  <span className="text-[10px] text-text-muted">
                    Broker:{" "}
                    <span className="font-mono tabular-nums text-text-secondary">
                      {broker.broker.toUpperCase()}
                    </span>
                  </span>
                  <span className="text-[10px] text-text-muted">
                    Daily P&L:{" "}
                    <span
                      className={`font-mono tabular-nums ${
                        dailyPnl >= 0 ? 'text-success-green' : 'text-danger-red'
                      }`}
                    >
                      {dailyPnl >= 0 ? '+' : ''}${dailyPnl.toLocaleString()}
                    </span>
                  </span>
                  <span className="text-[10px] text-text-muted">
                    Loss Budget:{" "}
                    <span className="font-mono tabular-nums text-danger-red">
                      ${lossBudgetRemaining.toLocaleString()} remaining
                    </span>
                  </span>
                </div>

                {killSwitch.active ? (
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-danger-red/10 px-2 py-1 text-[10px] font-bold text-danger-red">
                      KILLED
                    </span>
                    <button
                      onClick={() => setShowResetConfirm(true)}
                      className="flex h-8 w-8 items-center justify-center rounded border border-border-subtle bg-bg-input text-text-secondary transition-transform hover:scale-110 hover:text-text-primary active:scale-95"
                      title="Reset kill switch"
                      aria-label="Reset kill switch"
                    >
                      <RotateCcw className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowKillConfirm(true)}
                    className="flex h-8 w-8 items-center justify-center rounded bg-danger-red text-white transition-transform hover:scale-110 active:scale-95"
                    title="KILL SWITCH — Stop all trading immediately"
                    aria-label="Kill switch — stop all trading immediately"
                  >
                    <Octagon className="h-4 w-4" />
                  </button>
                )}
              </div>

              {killSwitch.active && killSwitch.reason && (
                <div className="mt-1 flex items-center gap-2 text-[10px] text-danger-red/80">
                  <X className="h-3 w-3" />
                  <span>
                    Reason: {killSwitch.reason}
                    {killSwitch.activatedAt && ` — ${killSwitch.activatedAt}`}
                  </span>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showKillConfirm && (
          <KillSwitchConfirmModal
            onConfirm={() => {
              activateKillSwitch('Manual kill switch activation');
              setShowKillConfirm(false);
            }}
            onCancel={() => setShowKillConfirm(false)}
          />
        )}
        {showResetConfirm && (
          <KillSwitchResetModal
            onConfirm={() => {
              resetKillSwitch();
              setShowResetConfirm(false);
            }}
            onCancel={() => setShowResetConfirm(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
});

export default LiveModeBanner;

import Layout from '@/components/Layout';

export default function Backtest() {
  return (
    <Layout title="Backtest">
      <div className="flex h-full items-center justify-center">
        <h1 className="text-2xl font-semibold text-text-primary">Backtest</h1>
      </div>
    </Layout>
  );
}

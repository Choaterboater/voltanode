import { useTradingMode } from '@/context/TradingModeContext';

export default function Footer() {
  const { isLive } = useTradingMode();

  return (
    <footer className="border-t border-border-subtle bg-bg-base px-6 py-4">
      <div className="flex items-center justify-between text-xs text-text-muted">
        <span>VoltaNode v1.0.0</span>
        <span className={isLive ? 'font-bold text-danger-red' : 'text-accent-cyan'}>
          {isLive ? 'LIVE TRADING MODE — REAL MONEY AT RISK' : 'Paper Trading Mode'}
        </span>
      </div>
    </footer>
  );
}

import Layout from '@/components/Layout';

export default function Strategies() {
  return (
    <Layout title="Strategies">
      <div className="flex h-full items-center justify-center">
        <h1 className="text-2xl font-semibold text-text-primary">Strategies</h1>
      </div>
    </Layout>
  );
}

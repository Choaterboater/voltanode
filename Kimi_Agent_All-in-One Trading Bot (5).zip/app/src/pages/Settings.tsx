import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Link2,
  Sliders,
  Octagon,
  Wallet,
  ChevronDown,
  RotateCcw,
  Loader2,
} from 'lucide-react';
import Layout from '@/components/Layout';
import Badge from '@/components/Badge';
import { useTradingMode } from '@/context/TradingModeContext';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

/* ─── Tab: Trading Mode ─── */
function TradingModeTab() {
  const {
    isLive,
    setLiveMode,
    apiKeysConfigured,
    brokerConnected,
    safetyLimitsSet,
    killSwitch,
  } = useTradingMode();

  const allChecksPass = apiKeysConfigured && brokerConnected && safetyLimitsSet;

  const checklist = [
    { label: 'API Keys Configured', done: apiKeysConfigured },
    { label: 'Broker Connected', done: brokerConnected },
    { label: 'Safety Limits Set', done: safetyLimitsSet },
  ];

  return (
    <div className="space-y-6">
      {/* Mode Card */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className={`rounded-xl border-2 p-6 ${
          isLive
            ? 'border-danger-red bg-danger-red-glow'
            : 'border-accent-cyan bg-accent-cyan-glow'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isLive ? (
              <AlertTriangle className="h-6 w-6 text-danger-red" />
            ) : (
              <Shield className="h-6 w-6 text-accent-cyan" />
            )}
            <div>
              <h3 className="text-lg font-bold text-text-primary">
                {isLive ? 'Live Trading Mode' : 'Paper Trading Mode'}
              </h3>
              <p className="text-sm text-text-secondary">
                {isLive
                  ? 'All orders use real money on your broker account.'
                  : 'Simulated trading with virtual balance. No real funds at risk.'}
              </p>
            </div>
          </div>
          <Badge variant={isLive ? 'danger' : 'cyan'}>
            {isLive ? 'LIVE' : 'PAPER'}
          </Badge>
        </div>

        {!isLive && killSwitch.active && (
          <div className="mt-4 rounded-lg border border-danger-red/30 bg-danger-red/10 p-3">
            <p className="text-xs font-bold text-danger-red">
              Kill Switch is Active — Trading Disabled
            </p>
            <p className="text-xs text-danger-red/70">
              Reason: {killSwitch.reason}
            </p>
          </div>
        )}
      </motion.div>

      {/* Checklist */}
      <div className="rounded-xl border border-border-subtle bg-bg-surface p-6">
        <h4 className="mb-4 text-sm font-semibold text-text-primary">
          Steps to Go Live
        </h4>
        <div className="space-y-3">
          {checklist.map((item) => (
            <div key={item.label} className="flex items-center gap-3">
              {item.done ? (
                <CheckCircle className="h-5 w-5 text-success-green" />
              ) : (
                <XCircle className="h-5 w-5 text-text-muted" />
              )}
              <span
                className={`text-sm ${
                  item.done ? 'text-text-primary' : 'text-text-muted'
                }`}
              >
                {item.label}
              </span>
            </div>
          ))}
        </div>
        <button
          onClick={() => allChecksPass && setLiveMode(true)}
          disabled={!allChecksPass || isLive || killSwitch.active}
          className={`mt-5 w-full rounded-lg py-3 text-sm font-bold tracking-wider transition-all active:scale-95 ${
            allChecksPass && !isLive && !killSwitch.active
              ? 'bg-danger-red text-white hover:bg-danger-red/80'
              : 'cursor-not-allowed bg-bg-elevated text-text-muted'
          }`}
        >
          {isLive ? 'ALREADY LIVE' : killSwitch.active ? 'KILL SWITCH ACTIVE' : 'GO LIVE'}
        </button>
      </div>
    </div>
  );
}

/* ─── Tab: Broker Setup ─── */
function BrokerSetupTab() {
  const { broker, setBroker, setBrokerConnected, setApiKeysConfigured } =
    useTradingMode();
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<'idle' | 'success' | 'error'>(
    'idle'
  );

  const handleBrokerChange = useCallback(
    (v: string) => setBroker({ broker: v as 'mock' | 'binance' | 'alpaca' }),
    [setBroker]
  );
  const handleApiKeyChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => setBroker({ apiKey: e.target.value }),
    [setBroker]
  );
  const handleApiSecretChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => setBroker({ apiSecret: e.target.value }),
    [setBroker]
  );
  const handleTestnetChange = useCallback(
    (v: boolean) => setBroker({ useTestnet: v }),
    [setBroker]
  );

  const handleTest = useCallback(() => {
    setTesting(true);
    setTestResult('idle');
    setTimeout(() => {
      const success = broker.apiKey.length > 3 && broker.apiSecret.length > 3;
      setTestResult(success ? 'success' : 'error');
      setBrokerConnected(success);
      if (success) setApiKeysConfigured(true);
      setTesting(false);
    }, 1500);
  }, [broker.apiKey, broker.apiSecret, setBrokerConnected, setApiKeysConfigured]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="rounded-xl border border-border-subtle bg-bg-surface p-6">
        <h4 className="mb-4 text-sm font-semibold text-text-primary">
          Broker Selection
        </h4>
        <div className="space-y-4">
          <div>
            <Label className="mb-2 block text-xs text-text-muted">
              Broker
            </Label>
            <Select
              value={broker.broker}
              onValueChange={handleBrokerChange}
            >
              <SelectTrigger className="w-full border-border-subtle bg-bg-input text-text-primary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mock">Mock (Simulation)</SelectItem>
                <SelectItem value="binance">Binance</SelectItem>
                <SelectItem value="alpaca">Alpaca</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="mb-2 block text-xs text-text-muted">
              API Key
            </Label>
            <Input
              type="password"
              value={broker.apiKey}
              onChange={handleApiKeyChange}
              placeholder="Enter your API key"
              className="border-border-subtle bg-bg-input text-text-primary"
            />
          </div>

          <div>
            <Label className="mb-2 block text-xs text-text-muted">
              API Secret
            </Label>
            <Input
              type="password"
              value={broker.apiSecret}
              onChange={handleApiSecretChange}
              placeholder="Enter your API secret"
              className="border-border-subtle bg-bg-input text-text-primary"
            />
          </div>

          <div className="flex items-center justify-between rounded-lg border border-border-subtle bg-bg-input p-3">
            <div className="flex items-center gap-2">
              <Link2 className="h-4 w-4 text-text-muted" />
              <span className="text-sm text-text-primary">Testnet / Paper</span>
            </div>
            <Switch
              checked={broker.useTestnet}
              onCheckedChange={handleTestnetChange}
            />
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleTest}
              disabled={testing}
              className="flex items-center gap-2 rounded-lg bg-accent-cyan px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-accent-cyan/80 disabled:opacity-50"
            >
              {testing && <Loader2 className="h-4 w-4 animate-spin" />}
              Test Connection
            </button>
            {testResult === 'success' && (
              <Badge variant="success">
                <CheckCircle className="mr-1 h-3 w-3" /> Connected
              </Badge>
            )}
            {testResult === 'error' && (
              <Badge variant="danger">
                <XCircle className="mr-1 h-3 w-3" /> Failed
              </Badge>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* ─── Tab: Safety Limits ─── */
function SafetyLimitsTab() {
  const { safetyStatus, setSafetyStatus, setSafetyLimitsSet } =
    useTradingMode();

  const handleChange = useCallback(
    (key: keyof typeof safetyStatus, value: unknown) => {
      setSafetyStatus({ [key]: value });
      setSafetyLimitsSet(true);
    },
    [setSafetyStatus, setSafetyLimitsSet]
  );

  const handleMaxDailyLossChange = useCallback(
    ([v]: number[]) => handleChange('maxDailyLossPct', v),
    [handleChange]
  );
  const handleMaxPositionChange = useCallback(
    ([v]: number[]) => handleChange('maxPositionSizePct', v),
    [handleChange]
  );
  const handleMaxExposureChange = useCallback(
    ([v]: number[]) => handleChange('maxExposurePct', v),
    [handleChange]
  );
  const handleMaxOrdersChange = useCallback(
    ([v]: number[]) => handleChange('maxOrdersPerMinute', v),
    [handleChange]
  );
  const handleRequireConfirmChange = useCallback(
    (v: boolean) => handleChange('requireOrderConfirmation', v),
    [handleChange]
  );
  const handleKillSwitchOnDisconnectChange = useCallback(
    (v: boolean) => handleChange('killSwitchOnDisconnect', v),
    [handleChange]
  );
  const handleAllowedSymbolsChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) =>
      handleChange('allowedSymbols', e.target.value),
    [handleChange]
  );
  const handleBlockedSymbolsChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) =>
      handleChange('blockedSymbols', e.target.value),
    [handleChange]
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="rounded-xl border border-border-subtle bg-bg-surface p-6">
        <h4 className="mb-4 flex items-center gap-2 text-sm font-semibold text-text-primary">
          <Sliders className="h-4 w-4 text-accent-cyan" />
          Risk Parameters
        </h4>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Max Daily Loss */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label className="text-xs text-text-muted">
                Max Daily Loss %
              </Label>
              <span className="font-mono text-sm tabular-nums text-text-primary">
                {safetyStatus.maxDailyLossPct}%
              </span>
            </div>
            <Slider
              value={[safetyStatus.maxDailyLossPct]}
              onValueChange={handleMaxDailyLossChange}
              min={1}
              max={50}
              step={1}
            />
          </div>

          {/* Max Position Size */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label className="text-xs text-text-muted">
                Max Position Size %
              </Label>
              <span className="font-mono text-sm tabular-nums text-text-primary">
                {safetyStatus.maxPositionSizePct}%
              </span>
            </div>
            <Slider
              value={[safetyStatus.maxPositionSizePct]}
              onValueChange={handleMaxPositionChange}
              min={5}
              max={100}
              step={5}
            />
          </div>

          {/* Max Exposure */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label className="text-xs text-text-muted">Max Exposure %</Label>
              <span className="font-mono text-sm tabular-nums text-text-primary">
                {safetyStatus.maxExposurePct}%
              </span>
            </div>
            <Slider
              value={[safetyStatus.maxExposurePct]}
              onValueChange={handleMaxExposureChange}
              min={10}
              max={100}
              step={5}
            />
          </div>

          {/* Max Orders Per Minute */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label className="text-xs text-text-muted">
                Max Orders / Minute
              </Label>
              <span className="font-mono text-sm tabular-nums text-text-primary">
                {safetyStatus.maxOrdersPerMinute}
              </span>
            </div>
            <Slider
              value={[safetyStatus.maxOrdersPerMinute]}
              onValueChange={handleMaxOrdersChange}
              min={1}
              max={60}
              step={1}
            />
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-border-subtle bg-bg-surface p-6">
        <h4 className="mb-4 text-sm font-semibold text-text-primary">
          Safety Controls
        </h4>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-primary">
                Require Order Confirmation
              </p>
              <p className="text-xs text-text-muted">
                Show confirmation dialog before every order
              </p>
            </div>
            <Switch
              checked={safetyStatus.requireOrderConfirmation}
              onCheckedChange={handleRequireConfirmChange}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-primary">
                Kill Switch on Disconnect
              </p>
              <p className="text-xs text-text-muted">
                Auto-activate kill switch if broker connection drops
              </p>
            </div>
            <Switch
              checked={safetyStatus.killSwitchOnDisconnect}
              onCheckedChange={handleKillSwitchOnDisconnectChange}
            />
          </div>

          <div>
            <Label className="mb-2 block text-xs text-text-muted">
              Allowed Symbols (comma-separated)
            </Label>
            <Input
              value={safetyStatus.allowedSymbols}
              onChange={handleAllowedSymbolsChange}
              placeholder="e.g. BTC,ETH,AAPL"
              className="border-border-subtle bg-bg-input text-text-primary"
            />
          </div>

          <div>
            <Label className="mb-2 block text-xs text-text-muted">
              Blocked Symbols (comma-separated)
            </Label>
            <Input
              value={safetyStatus.blockedSymbols}
              onChange={handleBlockedSymbolsChange}
              placeholder="e.g. MEME,SHIB"
              className="border-border-subtle bg-bg-input text-text-primary"
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* ─── Tab: Kill Switch ─── */
function KillSwitchTab() {
  const { killSwitch, activateKillSwitch, resetKillSwitch } =
    useTradingMode();
  const [showConfirm, setShowConfirm] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div
        className={`rounded-xl border-2 p-6 ${
          killSwitch.active
            ? 'border-danger-red bg-danger-red-glow'
            : 'border-border-subtle bg-bg-surface'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`flex h-10 w-10 items-center justify-center rounded-full ${
                killSwitch.active ? 'bg-danger-red/20' : 'bg-bg-elevated'
              }`}
            >
              <Octagon
                className={`h-5 w-5 ${
                  killSwitch.active ? 'text-danger-red' : 'text-text-muted'
                }`}
              />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-text-primary">
                Kill Switch
              </h4>
              <p className="text-xs text-text-muted">
                Status:{' '}
                <span
                  className={`font-bold ${
                    killSwitch.active ? 'text-danger-red' : 'text-success-green'
                  }`}
                >
                  {killSwitch.active ? 'ACTIVE' : 'INACTIVE'}
                </span>
              </p>
            </div>
          </div>
          <Badge variant={killSwitch.active ? 'danger' : 'success'}>
            {killSwitch.active ? 'TRADING STOPPED' : 'SYSTEM NORMAL'}
          </Badge>
        </div>

        {killSwitch.active && (
          <div className="mt-4 space-y-2 rounded-lg border border-danger-red/30 bg-danger-red/10 p-3">
            <p className="text-xs text-danger-red">
              <span className="font-bold">Reason:</span> {killSwitch.reason}
            </p>
            <p className="text-xs text-danger-red/80">
              <span className="font-bold">Activated:</span>{' '}
              {killSwitch.activatedAt}
            </p>
          </div>
        )}

        <div className="mt-5 flex gap-3">
          {!killSwitch.active ? (
            <button
              onClick={() => setShowConfirm(true)}
              className="w-full rounded-lg bg-danger-red py-3 text-sm font-bold tracking-wider text-white transition-colors hover:bg-danger-red/80 active:scale-95"
            >
              ACTIVATE KILL SWITCH
            </button>
          ) : (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="w-full rounded-lg border border-border-subtle bg-bg-input py-3 text-sm font-medium text-text-primary transition-colors hover:bg-bg-elevated active:scale-95"
            >
              <RotateCcw className="mr-2 inline h-4 w-4" />
              Reset Kill Switch
            </button>
          )}
        </div>
      </div>

      {/* Confirmation overlays */}
      {showConfirm && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70"
          onClick={() => setShowConfirm(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="mx-4 w-full max-w-sm rounded-xl border-2 border-danger-red bg-bg-surface p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-danger-red-glow">
                <Octagon className="h-6 w-6 text-danger-red" />
              </div>
              <h3 className="mt-3 text-lg font-bold text-danger-red">
                ACTIVATE KILL SWITCH?
              </h3>
              <p className="mt-2 text-sm text-text-secondary">
                All trading will stop immediately. Open orders will be
                cancelled.
              </p>
              <div className="mt-5 flex w-full gap-3">
                <button
                  onClick={() => setShowConfirm(false)}
                  className="flex-1 rounded-lg border border-border-subtle bg-bg-input px-4 py-2 text-sm font-medium text-text-primary"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    activateKillSwitch('Manual activation from Settings');
                    setShowConfirm(false);
                  }}
                  className="flex-1 rounded-lg bg-danger-red px-4 py-2 text-sm font-bold text-white hover:bg-danger-red/80"
                >
                  CONFIRM
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {showResetConfirm && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70"
          onClick={() => setShowResetConfirm(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="mx-4 w-full max-w-sm rounded-xl border border-border-subtle bg-bg-surface p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-warning-amber/10">
                <RotateCcw className="h-6 w-6 text-warning-amber" />
              </div>
              <h3 className="mt-3 text-lg font-bold text-text-primary">
                Reset Kill Switch?
              </h3>
              <p className="mt-2 text-sm text-text-secondary">
                Re-enable trading. Verify the issue is resolved first.
              </p>
              <div className="mt-5 flex w-full gap-3">
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="flex-1 rounded-lg border border-border-subtle bg-bg-input px-4 py-2 text-sm font-medium text-text-primary"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    resetKillSwitch();
                    setShowResetConfirm(false);
                  }}
                  className="flex-1 rounded-lg bg-accent-cyan px-4 py-2 text-sm font-bold text-white hover:bg-accent-cyan/80"
                >
                  RESET
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}

/* ─── Tab: Paper Mode Settings ─── */
function PaperModeSettingsTab() {
  const { paperSettings, setPaperSettings } = useTradingMode();

  const handleVirtualBalanceChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setPaperSettings({ virtualBalance: Number(e.target.value) }),
    [setPaperSettings]
  );

  const handleSlippageChange = useCallback(
    (v: string) => setPaperSettings({ slippageModel: v }),
    [setPaperSettings]
  );

  const handleFeeChange = useCallback(
    ([v]: number[]) => setPaperSettings({ feePct: v }),
    [setPaperSettings]
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="rounded-xl border border-border-subtle bg-bg-surface p-6">
        <h4 className="mb-4 flex items-center gap-2 text-sm font-semibold text-text-primary">
          <Wallet className="h-4 w-4 text-accent-cyan" />
          Virtual Environment
        </h4>

        <div className="space-y-4">
          <div>
            <Label className="mb-2 block text-xs text-text-muted">
              Virtual Balance ($)
            </Label>
            <Input
              type="number"
              value={paperSettings.virtualBalance}
              onChange={handleVirtualBalanceChange}
              className="border-border-subtle bg-bg-input font-mono text-text-primary"
            />
          </div>

          <div>
            <Label className="mb-2 block text-xs text-text-muted">
              Slippage Model
            </Label>
            <Select
              value={paperSettings.slippageModel}
              onValueChange={handleSlippageChange}
            >
              <SelectTrigger className="w-full border-border-subtle bg-bg-input text-text-primary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fixed-0.1%">Fixed 0.1%</SelectItem>
                <SelectItem value="fixed-0.05%">Fixed 0.05%</SelectItem>
                <SelectItem value="variable">Variable (market depth)</SelectItem>
                <SelectItem value="none">No slippage</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label className="text-xs text-text-muted">Fee %</Label>
              <span className="font-mono text-sm tabular-nums text-text-primary">
                {paperSettings.feePct}%
              </span>
            </div>
            <Slider
              value={[paperSettings.feePct]}
              onValueChange={handleFeeChange}
              min={0}
              max={1}
              step={0.01}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* ─── Settings Page ─── */
export default function Settings() {
  const [activeTab, setActiveTab] = useState('mode');

  const tabs = [
    { id: 'mode', label: 'Trading Mode', icon: Shield },
    { id: 'broker', label: 'Broker Setup', icon: Link2 },
    { id: 'safety', label: 'Safety Limits', icon: Sliders },
    { id: 'kill', label: 'Kill Switch', icon: Octagon },
    { id: 'paper', label: 'Paper Settings', icon: Wallet },
  ];

  return (
    <Layout
      title="Settings"
      rightContent={
        <Badge variant="neutral">
          <ChevronDown className="mr-1 h-3 w-3" />
          v1.0.0
        </Badge>
      }
    >
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-6 h-auto w-full flex-wrap justify-start gap-1 bg-bg-surface p-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className="flex items-center gap-2 rounded-md px-3 py-2 text-xs data-[state=active]:bg-bg-elevated data-[state=active]:text-accent-cyan"
              >
                <Icon className="h-3.5 w-3.5" />
                {tab.label}
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value="mode">
          <TradingModeTab />
        </TabsContent>
        <TabsContent value="broker">
          <BrokerSetupTab />
        </TabsContent>
        <TabsContent value="safety">
          <SafetyLimitsTab />
        </TabsContent>
        <TabsContent value="kill">
          <KillSwitchTab />
        </TabsContent>
        <TabsContent value="paper">
          <PaperModeSettingsTab />
        </TabsContent>
      </Tabs>
    </Layout>
  );
}

import Layout from '@/components/Layout';

export default function Analytics() {
  return (
    <Layout title="Analytics">
      <div className="flex h-full items-center justify-center">
        <h1 className="text-2xl font-semibold text-text-primary">Analytics</h1>
      </div>
    </Layout>
  );
}
